import React from "react";
import html2pdf from "html2pdf.js";

const HtmlToPdfConverter = () => {
  const convertToPdf = () => {
    const element = document.getElementById("content-to-convert");
    const opt = {
      margin: 10,
      filename: "converted.pdf",
      image: { type: "jpeg", quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
    };

    html2pdf().from(element).set(opt).save();
  };

  return (
    <div>
      {/* Content that you want to convert to PDF */}
      <div id="content-to-convert">
        <h1>Hello, PDF!</h1>
        <p>This is the content that will be converted to PDF.</p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
        <p>
          Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nam quidem
          aperiam sunt excepturi, necessitatibus minima laudantium suscipit
          explicabo laboriosam provident fugiat in ratione corrupti, optio
          nesciunt dolorum, ipsa quod blanditiis.
        </p>
      </div>

      {/* Button to trigger the conversion */}
      <button onClick={convertToPdf}>Convert to PDF</button>
    </div>
  );
};

export default HtmlToPdfConverter;
